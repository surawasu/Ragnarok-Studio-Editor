using System.Diagnostics;
using System.Text;
using System.IO.Compression;
namespace MavenROStudio;
static class Verify {
    public static int Run(string[] args) {
        var log=new List<string>();int exit=0;
        try {
            var ct=CancellationToken.None;
            var rows=LuaData.Parse(Encoding.UTF8.GetBytes("tbl = { [501] = { identifiedDisplayName = \"Potion\", identifiedResourceName = \"포션\", identifiedDescriptionName = {\"a } [999] =\", \"b\"} }, -- comment\n [502] = { identifiedDisplayName = \"Second\", identifiedResourceName = \"test\" } }"),"test",65001,ct);
            if(rows.Count!=2||rows[0].Id!=501||!rows[0].Description.Contains("a }"))throw new Exception("Lua string/braces regression");
            try{LuaData.Parse([27,76,117,97],"compiled",874,ct);throw new Exception("Bytecode was not rejected");}catch(InvalidDataException){}
            try{LuaData.Parse(Encoding.ASCII.GetBytes("x = {[1]={identifiedDisplayName=\"unterminated"),"bad",874,ct);throw new Exception("Bad Lua accepted");}catch(InvalidDataException){}
            log.Add("PASS literal Lua parser, quoted braces, comments, truncated LUB rejection, truncated string rejection");
            var cancelled=new CancellationToken(true);
            try {LuaData.Parse(Encoding.ASCII.GetBytes("x = {}"),"cancel",874,cancelled);throw new Exception("Cancellation ignored");} catch(OperationCanceledException){}
            log.Add("PASS parser cancellation");
            int p=Array.IndexOf(args,"--client");
            if(p>=0&&p+1<args.Length) {
                var sw=Stopwatch.StartNew();var a=new Assets();a.Load(args[p+1],false,ct,_=>{});
                log.Add($"GRF index: {a.Entries.Count:N0} winning entries; {sw.Elapsed.TotalSeconds:N2}s; managed memory {GC.GetTotalMemory(false)/1048576:N0} MiB");
                log.AddRange(a.Messages);
                foreach(var entry in a.Entries.Values.Where(e=>e.Path.Contains("iteminfo",StringComparison.OrdinalIgnoreCase)))log.Add("Packed itemInfo candidate: "+Assets.Display(entry.Path)+" @ "+Path.GetFileName(entry.Archive));
                if(Assets.RawKey(Assets.Display(Assets.RawKey(@"data\texture\유저인터페이스\item\빨간포션.bmp")))!=Assets.RawKey(@"data\texture\유저인터페이스\item\빨간포션.bmp"))throw new Exception("CP949 path roundtrip failed");
                log.Add("PASS Korean path byte preservation");
                int found=0, encrypted=0, failed=0;
                foreach(var asset in a.Entries.Values.Where(x=>x.Path.EndsWith(".bmp",StringComparison.OrdinalIgnoreCase)&&Assets.Display(x.Path).Contains(@"\item\",StringComparison.OrdinalIgnoreCase)).Take(100)) {
                    try {var data=a.Read(asset.Path,ct);using var ms=new MemoryStream(data.Bytes);using var img=System.Drawing.Image.FromStream(ms);found++;}
                    catch(NotSupportedException){encrypted++;}
                    catch(Exception ex){failed++;log.Add("IMAGE FAIL "+Assets.Display(asset.Path)+" "+ex.Message);}
                }
                log.Add($"Image sample: decoded {found}; unsupported encrypted {encrypted}; failures {failed}");
                if(failed>0)exit=1;
                var info=Path.Combine(args[p+1],"System","itemInfo_true.lub");
                if(File.Exists(info)) {
                    try{
                        sw.Restart();var items=LuaData.Parse(File.ReadAllBytes(info),info,949,ct);
                        log.Add($"Real itemInfo: {items.Count:N0} entries, {sw.Elapsed.TotalSeconds:N2}s");
                        foreach(var i in items.Where(x=>x.Id==54000||x.Id==501)) {
                            log.Add($"Item {i.Id}: {i.Name}; resource={Assets.Display(i.Resource)}");
                            try{var data=a.ItemImage(i,false,ct);using var ms=new MemoryStream(data.Bytes);using var img=Image.FromStream(ms);log.Add($"Item {i.Id} image: {img.Width}x{img.Height}; {data.Source}");}
                            catch(Exception ex){log.Add($"Item {i.Id} image unresolved: {ex.Message}");}
                        }
                    }catch(Exception ex){log.Add("Real itemInfo unsupported or invalid: "+ex.Message);exit=1;}
                }
            }
            int d=Array.IndexOf(args,"--db");
            if(d>=0&&d+1<args.Length){var sw=Stopwatch.StartNew();var items=ItemDb.Load(args[d+1],ct);log.Add($"Real YAML: {items.Count:N0} items, {sw.Elapsed.TotalSeconds:N2}s");if(items.Count==0)exit=1;}
        }catch(Exception ex){log.Add(ex.ToString());exit=1;}
        log.Add("Exit="+exit);
        File.WriteAllLines(Path.Combine(AppContext.BaseDirectory,"verification.txt"),log,new UTF8Encoding(false));
        return exit;
    }
}
