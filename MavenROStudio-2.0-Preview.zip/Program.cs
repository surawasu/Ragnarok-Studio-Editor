using System.Diagnostics;
using System.Text;
using System.Text.Json;

namespace MavenROStudio;
static class Program {
    [STAThread] static int Main(string[] args) {
        Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
        if (args.Contains("--verify")) return Verify.Run(args);
        ApplicationConfiguration.Initialize();
        Application.ThreadException += (_,e) => MessageBox.Show(e.Exception.Message, "RO Studio");
        Application.Run(new Studio(args.Contains("--ui-smoke")));
        return 0;
    }
}
public sealed class Settings {
    public string Client {get;set;} = @"D:\MAVEN-RO\06_Client-14_10_2025 By Speedrun";
    public string ItemInfo {get;set;} = "";
    public int Encoding {get;set;} = 949;
    public bool LooseFirst {get;set;}
}
public sealed class Studio : Form {
    readonly TextBox query = new() { Width = 280, PlaceholderText = "ค้นหา ID / ชื่อ / Resource" };
    readonly TextBox client = new() { Width = 380 };
    readonly ComboBox encoding = new() { DropDownStyle = ComboBoxStyle.DropDownList, Width = 135 };
    readonly CheckBox loose = new() { Text = "Read data folder first", AutoSize = true };
    readonly CheckBox collection = new() { Text = "Collection image", AutoSize = true };
    readonly Label status = new() { Dock = DockStyle.Bottom, Height = 32, TextAlign = ContentAlignment.MiddleLeft };
    readonly ListView list = new() { Dock=DockStyle.Fill, View=View.Details, VirtualMode=true, FullRowSelect=true, HideSelection=false };
    readonly ListView grfs = new() { Dock=DockStyle.Fill, View=View.Details, VirtualMode=true, FullRowSelect=true };
    readonly TextBox details = new() { Dock=DockStyle.Fill, Multiline=true, ReadOnly=true, ScrollBars=ScrollBars.Both, WordWrap=false };
    readonly TextBox log = new() { Dock=DockStyle.Fill, Multiline=true, ReadOnly=true, ScrollBars=ScrollBars.Both };
    readonly PictureBox picture = new() { Dock=DockStyle.Top, Height=180, SizeMode=PictureBoxSizeMode.Zoom, BackColor=Color.FromArgb(38,38,45) };
    readonly System.Windows.Forms.Timer debounce = new() { Interval=250 };
    readonly List<Button> loadButtons = [];
    List<Item> items = [], filtered = [];
    Dictionary<int,Item> clientItems = [], serverItems = [];
    List<Asset> assetRows = [], filteredAssets = [];
    Assets? assets;
    CancellationTokenSource? loadCancel, filterCancel, imageCancel;
    readonly SemaphoreSlim imageGate = new(1,1);
    int imageGeneration;
    Settings settings = new();
    readonly string settingsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),"MavenROStudio","settings.json");
    public Studio(bool smoke=false) {
        if(smoke) Shown += async (_,_)=>{
            var evidence=new List<string>();int ticks=0;
            using var heartbeat=new System.Windows.Forms.Timer{Interval=25};
            heartbeat.Tick+=(_,_)=>ticks++;heartbeat.Start();
            try {
                await LoadAssets();
                if(assets==null||assetRows.Count==0)throw new Exception("UI asset load failed");
                evidence.Add("GRF UI load: "+assetRows.Count+" assets; UI timer ticks during load="+ticks);
                if(ticks<2)throw new Exception("UI heartbeat did not advance during load");
                var file=Path.Combine(client.Text,"System","itemInfo_true.lub");
                var rows=await Task.Run(()=>LuaData.Parse(File.ReadAllBytes(file),file,949,CancellationToken.None));
                clientItems=rows.ToDictionary(i=>i.Id);Merge();query.Text="501";await Filter();
                int index=filtered.FindIndex(i=>i.Id==501);
                if(index<0)throw new Exception("Search did not find item 501");
                list.Items[index].Selected=true;await ShowItem();
                if(picture.Image==null)throw new Exception("UI item preview missing");
                evidence.Add("PASS item 501 selection, image preview, source display, filtered virtual list");
                using var image=new Bitmap(Width,Height);DrawToBitmap(image,new Rectangle(0,0,Width,Height));
                image.Save(Path.Combine(AppContext.BaseDirectory,"ui-preview.png"));
                evidence.Add("PASS UI smoke");
            }catch(Exception ex){evidence.Add("FAIL "+ex);}
            File.WriteAllLines(Path.Combine(AppContext.BaseDirectory,"ui-smoke.txt"),evidence);
            Close();
        };
        Text = "MAVEN RO Studio 2.0 • Item & GRF Workbench";
        Size = new Size(1280,820); MinimumSize = new Size(950,620);
        Font = new Font("Segoe UI",10);
        BackColor = Color.FromArgb(245,244,248);
        var bar = new FlowLayoutPanel { Dock=DockStyle.Top, AutoSize=true, WrapContents=true, Padding=new Padding(8) };
        var actions = new FlowLayoutPanel { Dock=DockStyle.Top, AutoSize=true, Padding=new Padding(8) };
        bar.Controls.Add(new Label { Text="Client folder", AutoSize=true, Padding=new Padding(0,6,0,0) });
        bar.Controls.Add(client);
        Add(bar,"เลือก Client",()=> { using var d=new FolderBrowserDialog(); if(d.ShowDialog()==DialogResult.OK) client.Text=d.SelectedPath; });
        Add(bar,"โหลด GRF",async()=>await LoadAssets());
        bar.Controls.Add(loose);
        Add(bar,"ยกเลิกโหลด",()=>loadCancel?.Cancel(), false);
        encoding.Items.AddRange(["Thai CP874","UTF-8","Korean CP949"]); encoding.SelectedIndex=0;
        actions.Controls.Add(encoding);
        Add(actions,"เปิด itemInfo",async()=>await OpenInfo());
        Add(actions,"เพิ่ม Item DB",async()=>await OpenDb());
        Add(actions,"ล้าง Item DB",()=> { serverItems.Clear(); Merge(); });
        actions.Controls.Add(query); actions.Controls.Add(collection);
        Add(actions,"Export CSV",ExportCsv);
        var tabs = new TabControl { Dock=DockStyle.Fill };
        var itemTab = new TabPage("Item Inspector");
        var split = new TableLayoutPanel { Dock=DockStyle.Fill, ColumnCount=2, RowCount=1 };
        split.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,55));
        split.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,45));
        var right = new Panel { Dock=DockStyle.Fill, Padding=new Padding(8) };
        right.Controls.Add(details); right.Controls.Add(picture);
        split.Controls.Add(list,0,0); split.Controls.Add(right,1,0); itemTab.Controls.Add(split);
        var grfTab = new TabPage("GRF Explorer"); grfTab.Controls.Add(grfs);
        var logTab = new TabPage("Diagnostics"); logTab.Controls.Add(log);
        tabs.TabPages.AddRange([itemTab,grfTab,logTab]);
        Controls.Add(tabs); Controls.Add(actions); Controls.Add(bar); Controls.Add(status);
        list.Columns.Add("ID",85); list.Columns.Add("ชื่อไอเทม",240); list.Columns.Add("Resource",200); list.Columns.Add("Data",100);
        grfs.Columns.Add("Resource path",620); grfs.Columns.Add("GRF",220); grfs.Columns.Add("Bytes",100); grfs.Columns.Add("Flags",65);
        list.RetrieveVirtualItem += (_,e)=> {
            if(e.ItemIndex>=filtered.Count) {e.Item=new ListViewItem("");return;}
            var i=filtered[e.ItemIndex];
            e.Item=new ListViewItem([i.Id.ToString(),i.Name,ResourceDisplay(i),clientItems.ContainsKey(i.Id)?(serverItems.ContainsKey(i.Id)?"Client + DB":"Client only"):"DB only"]);
        };
        grfs.RetrieveVirtualItem += (_,e)=> {
            if(e.ItemIndex>=filteredAssets.Count) {e.Item=new ListViewItem("");return;}
            var a=filteredAssets[e.ItemIndex]; e.Item=new ListViewItem([Assets.Display(a.Path),Path.GetFileName(a.Archive),a.Size.ToString("N0"),a.Flags.ToString()]);
        };
        grfs.DoubleClick += async (_,_)=>{
            if(assets==null||grfs.SelectedIndices.Count==0)return;
            var asset=filteredAssets[grfs.SelectedIndices[0]];
            if(!asset.Path.Contains("iteminfo",StringComparison.OrdinalIgnoreCase)) {
                MessageBox.Show(Assets.Display(asset.Path)+"\r\n"+asset.Archive+"\r\nSize: "+asset.Size+"\r\nFlags: "+asset.Flags,"Resource source");return;
            }
            int cp=Codepage;var snapshot=assets;
            await Work(async ct=>{
                var data=await Task.Run(()=>snapshot.Read(asset.Path,ct),ct);
                var rows=await Task.Run(()=>LuaData.Parse(data.Bytes,data.Source,cp,ct),ct);
                ct.ThrowIfCancellationRequested();clientItems=rows.ToDictionary(x=>x.Id);
                Merge();query.Clear();tabs.SelectedTab=itemTab;
                Log("Loaded packed itemInfo: "+data.Source+"; items="+rows.Count);await Filter();
            });
        };
        list.SelectedIndexChanged += async (_,_)=>await ShowItem();
        collection.CheckedChanged += async (_,_)=>await ShowItem();
        query.TextChanged += (_,_)=> { debounce.Stop(); debounce.Start(); };
        debounce.Tick += async (_,_)=> {debounce.Stop(); await Filter();};
        FormClosing += (_,_)=> {loadCancel?.Cancel();filterCancel?.Cancel();imageCancel?.Cancel();SaveSettings();};
        FormClosed += (_,_)=>picture.Image?.Dispose();
        try { if(File.Exists(settingsPath)) settings=JsonSerializer.Deserialize<Settings>(File.ReadAllText(settingsPath))??new(); }
        catch(Exception ex){Log("Settings: "+ex.Message);}
        client.Text=settings.Client; loose.Checked=settings.LooseFirst;
        encoding.SelectedIndex=settings.Encoding==65001?1:settings.Encoding==949?2:0;
        status.Text="พร้อมใช้งาน • เลือก Client → โหลด GRF → เปิด itemInfo | โปรแกรมอ่านไฟล์เกมโดยไม่แก้ต้นฉบับ";
    }
    int Codepage => encoding.SelectedIndex==1?65001:encoding.SelectedIndex==2?949:874;
    static string ResourceDisplay(Item i)=>i.UnicodeResource?i.Resource:Assets.Display(i.Resource);
    void Add(FlowLayoutPanel p,string text,Action action,bool loading=true) {
        var b=new Button {Text=text,AutoSize=true,Height=32,FlatStyle=FlatStyle.Flat};
        b.Click+=(_,_)=>action(); p.Controls.Add(b); if(loading)loadButtons.Add(b);
    }
    void Log(string message) {log.AppendText(DateTime.Now.ToString("HH:mm:ss")+" "+message+Environment.NewLine);}
    void SaveSettings() {
        try {
            settings.Client=client.Text; settings.LooseFirst=loose.Checked;settings.Encoding=Codepage;
            Directory.CreateDirectory(Path.GetDirectoryName(settingsPath)!);
            var temp=settingsPath+".tmp"; File.WriteAllText(temp,JsonSerializer.Serialize(settings,new JsonSerializerOptions{WriteIndented=true}));
            File.Move(temp,settingsPath,true);
        } catch(Exception ex){Log(ex.Message);}
    }
    async Task Work(Func<CancellationToken,Task> action) {
        if(loadCancel!=null)return;
        var cts=new CancellationTokenSource();loadCancel=cts;
        foreach(var b in loadButtons)b.Enabled=false;
        var watch=Stopwatch.StartNew();
        try {await action(cts.Token);status.Text=$"เสร็จใน {watch.Elapsed.TotalSeconds:N2} วินาที • Items {items.Count:N0} • Assets {assetRows.Count:N0}";SaveSettings();}
        catch(OperationCanceledException){status.Text="ยกเลิกแล้ว — คงข้อมูลชุดก่อนหน้า";}
        catch(Exception ex){status.Text="โหลดไม่สำเร็จ: "+ex.Message;Log(ex.ToString());}
        finally{foreach(var b in loadButtons)b.Enabled=true;loadCancel=null;cts.Dispose();}
    }
    async Task LoadAssets() {
        string root=client.Text;bool lf=loose.Checked;
        await Work(async ct=>{
            var progress=new Progress<string>(s=>{if(!IsDisposed)status.Text=s;});
            var a=await Task.Run(()=>{var v=new Assets();v.Load(root,lf,ct,s=>((IProgress<string>)progress).Report(s));return v;},ct);
            ct.ThrowIfCancellationRequested();assets=a;
            assetRows=await Task.Run(()=>a.Entries.Values.OrderBy(x=>x.Path,StringComparer.OrdinalIgnoreCase).ToList(),ct);
            foreach(var m in a.Messages)Log(m);
            Log("Loose data priority: "+lf+" (must match your client patch)");
            await Filter();await ShowItem();
        });
    }
    async Task OpenInfo() {
        using var d=new OpenFileDialog {Filter="Item info (*.lua;*.lub)|*.lua;*.lub|All files|*.*",InitialDirectory=Directory.Exists(client.Text)?client.Text:""};
        if(d.ShowDialog()!=DialogResult.OK)return;
        int cp=Codepage; string file=d.FileName;
        await Work(async ct=>{
            var rows=await Task.Run(()=>LuaData.Parse(File.ReadAllBytes(file),file,cp,ct),ct);
            ct.ThrowIfCancellationRequested();clientItems=rows.ToDictionary(x=>x.Id);settings.ItemInfo=file;Merge();Log($"itemInfo {rows.Count:N0} entries: {file}; encoding {cp}");await Filter();
        });
    }
    async Task OpenDb() {
        using var d=new OpenFileDialog {Filter="Item DB (*.yml;*.yaml)|*.yml;*.yaml",Multiselect=true};
        if(d.ShowDialog()!=DialogResult.OK)return;
        var files=d.FileNames;
        await Work(async ct=>{
            var merged=new Dictionary<int,Item>(serverItems);
            await Task.Run(()=>{foreach(var file in files)foreach(var i in ItemDb.Load(file,ct))merged[i.Id]=i;},ct);
            ct.ThrowIfCancellationRequested();serverItems=merged;Merge();
            foreach(var f in files)Log("DB merge (later file wins): "+f);
            Log("Import-only YAML files must be opened as their individual Body files; imports are not auto-followed.");
            await Filter();
        });
    }
    void Merge() {
        var merged=new Dictionary<int,Item>(serverItems);
        foreach(var i in clientItems.Values)merged[i.Id]=i;
        items=merged.Values.OrderBy(x=>x.Id).ToList();
        _=Filter();
    }
    async Task Filter() {
        filterCancel?.Cancel();var c=new CancellationTokenSource();filterCancel=c;string q=query.Text.Trim();
        var itemSnapshot=items;var assetSnapshot=assetRows;
        try {
            var result=await Task.Run(()=>{
                var it=new List<Item>();var ar=new List<Asset>();
                foreach(var i in itemSnapshot){c.Token.ThrowIfCancellationRequested();if(q.Length==0||i.Id.ToString().Contains(q)||i.Name.Contains(q,StringComparison.OrdinalIgnoreCase)||ResourceDisplay(i).Contains(q,StringComparison.OrdinalIgnoreCase))it.Add(i);}
                foreach(var a in assetSnapshot){c.Token.ThrowIfCancellationRequested();if(q.Length==0||Assets.Display(a.Path).Contains(q,StringComparison.OrdinalIgnoreCase))ar.Add(a);}
                return(it,ar);
            },c.Token);
            if(c.IsCancellationRequested||IsDisposed)return;
            list.VirtualListSize=0;grfs.VirtualListSize=0;filtered=result.it;filteredAssets=result.ar;
            list.VirtualListSize=filtered.Count;grfs.VirtualListSize=filteredAssets.Count;
            list.Invalidate();grfs.Invalidate();
            status.Text=$"Items {filtered.Count:N0}/{items.Count:N0} • Resources {filteredAssets.Count:N0}/{assetRows.Count:N0}";
        }catch(OperationCanceledException){}
        finally{if(filterCancel==c)filterCancel=null;c.Dispose();}
    }
    async Task ShowItem() {
        imageCancel?.Cancel();var c=new CancellationTokenSource();imageCancel=c;int generation=++imageGeneration;
        picture.Image?.Dispose();picture.Image=null;
        if(list.SelectedIndices.Count==0){c.Dispose();imageCancel=null;return;}
        var n=list.SelectedIndices[0];if(n>=filtered.Count){c.Dispose();imageCancel=null;return;}
        var i=filtered[n];var a=assets;bool coll=collection.Checked;
        var description=$"ID: {i.Id}\r\nName: {i.Name}\r\nResource: {ResourceDisplay(i)}\r\nSource: {i.Source}\r\n\r\n{i.Description}";
        if(serverItems.TryGetValue(i.Id,out var db))description+="\r\n\r\nSERVER DB: "+db.Source+"\r\n"+db.Raw;
        details.Text=description;
        if(a==null){details.AppendText("\r\n\r\nกรุณาโหลด GRF เพื่อแสดงรูป");if(imageCancel==c)imageCancel=null;c.Dispose();return;}
        bool entered=false;
        try {
            await imageGate.WaitAsync(c.Token);entered=true;
            var result=await Task.Run(()=>{
                var data=a.ItemImage(i,coll,c.Token);
                using var ms=new MemoryStream(data.Bytes);using var source=Image.FromStream(ms);
                if(source.Width>4096||source.Height>4096)throw new InvalidDataException("Image preview dimensions too large.");
                var bmp=new Bitmap(source);bmp.MakeTransparent(Color.Magenta);
                return (Image:bmp,data.Source);
            },c.Token);
            if(c.IsCancellationRequested||generation!=imageGeneration||IsDisposed){result.Image.Dispose();return;}
            picture.Image=result.Image;details.AppendText("\r\n\r\nIMAGE: "+result.Source);
        }catch(OperationCanceledException){}
        catch(Exception ex){if(generation==imageGeneration&&!IsDisposed)details.AppendText("\r\n\r\nIMAGE ERROR: "+ex.Message);}
        finally{if(entered)imageGate.Release();if(imageCancel==c)imageCancel=null;c.Dispose();}
    }
    void ExportCsv() {
        using var d=new SaveFileDialog{Filter="CSV|*.csv",FileName="items.csv"};
        if(d.ShowDialog()!=DialogResult.OK)return;
        try {
            string Q(string s)=>"\""+s.Replace("\"","\"\"")+"\"";
            File.WriteAllLines(d.FileName,new[]{"Id,Name,Resource,Source"}.Concat(filtered.Select(i=>$"{i.Id},{Q(i.Name)},{Q(ResourceDisplay(i))},{Q(i.Source)}")),new UTF8Encoding(true));
            Log("Exported "+d.FileName);
        }catch(Exception ex){MessageBox.Show(ex.Message);}
    }
}
