# MAVEN RO Studio 2.0 — Preview

สร้างใหม่ 3 ตุลาคม 2026 เป็นรุ่นแกนอ่านข้อมูลและตรวจไอเทม ยังไม่ใช่การย้ายฟีเจอร์ทั้งหมดจาก RO Studio เดิม

## เปิดโปรแกรม

เปิด release-2.0/MavenROStudio.exe บน Windows x64 ที่มี .NET Desktop Runtime 10 (เครื่องที่ build มีแล้ว) เก็บไฟล์ในโฟลเดอร์ release-2.0 ไว้ด้วยกัน

1. เลือกโฟลเดอร์ Client ที่มี DATA.ini แล้วกด โหลด GRF
2. เลือก encoding ให้ตรงกับ itemInfo: CP949 สำหรับไฟล์เกาหลี, CP874 สำหรับไทย, UTF-8 สำหรับไฟล์ UTF-8
3. เปิด itemInfo .lua หรือ .lub รองรับข้อมูล literal และ bytecode Lua 5.1 มาตรฐานแบบ little-endian
4. หาก itemInfo อยู่ใน GRF: เปิด GRF Explorer ค้น iteminfo แล้วดับเบิลคลิกไฟล์ที่ต้องการ
5. เพิ่ม Item DB YAML ได้หลายไฟล์ ไฟล์ที่โหลดทีหลังทับ ID เดิม; เปิดไฟล์ที่มี Body โดยตรง ไม่ไล่ Footer imports อัตโนมัติ
6. ค้นไอเทมและเลือกเพื่อดูรูป ข้อมูล และแหล่งไฟล์; สลับ Collection image ได้
7. Export CSV เป็นรายการที่กรองอยู่

## ความถูกต้อง

- อ่าน GRF ตามตัวเลขใน [Data] ของ DATA.ini; ไฟล์แรกชนะเมื่อชื่อ resource ซ้ำ
- เก็บชื่อไฟล์เป็นไบต์เดิมและแปลง ASCII case เท่านั้น ป้องกันชื่อเกาหลีเสีย
- Read data folder first ต้องตั้งให้ตรงกับแพตช์ของ Client ผู้ใช้ โปรแกรมยังไม่ตรวจ executable patch อัตโนมัติ
- ผู้ใช้ต้องเลือก itemInfo ตัวเดียวกับเกม ไม่สามารถสรุปจากปี Client อย่างเดียว
- แยกชื่อแสดงผลจาก resource bytes; ไม่มีการเดารูปจาก Item ID
- แสดงข้อผิดพลาดเมื่อ resource ขาด/เข้ารหัส ไม่ใช้ภาพอื่นแทน

## ประสิทธิภาพและขอบเขต

อ่านเฉพาะ GRF index และ asset ที่เลือก, virtual list, background load/search, debounce, cancellation, จำกัดงานถอดรูปพร้อมกันและ dispose รูปเก่า

ยังไม่รองรับ GRF ที่เข้ารหัส, Lua ที่สร้างตารางด้วยการเรียกฟังก์ชัน/loop, preview SPR/ACT สวมใส่, Barter/NPC/Monster/Collection editors และการเขียนกลับไฟล์เกม รุ่นนี้อ่านไฟล์เกมและ export รายการเท่านั้น

## Build / Verify

ใช้ dotnet publish -c Release -r win-x64 --self-contained false -o release-2.0

MavenROStudio.exe --verify --client "CLIENT_FOLDER" --db "ITEM_DB_YAML"
MavenROStudio.exe --ui-smoke

ผลตรวจอยู่ verification.txt และ ui-smoke.txt ข้าง exe; ui-preview.png เป็นภาพหน้าต่างจาก smoke test

ข้อมูลอ้างอิงรูปแบบ: https://www.lua.org/source/5.1/lopcodes.h.html และ https://www.lua.org/source/5.1/lundump.c.html ; GRF: https://ragnarokresearchlab.github.io/file-formats/grf/
ใช้ YamlDotNet 16.3.0 (MIT) ผ่าน NuGet
