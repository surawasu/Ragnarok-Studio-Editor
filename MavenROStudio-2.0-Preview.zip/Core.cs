using System.Diagnostics;
using System.IO.Compression;
using System.Text;
using System.Text.RegularExpressions;
using YamlDotNet.RepresentationModel;

namespace MavenROStudio;

public sealed record Item(int Id, string Name, string Resource, string Description, string Source, string Raw, bool UnicodeResource = false);
public sealed record Asset(string Path, string Archive, long Offset, int Compressed, int Size, byte Flags);
public sealed class Assets {
    public Dictionary<string, Asset> Entries { get; } = new(StringComparer.Ordinal);
    public List<string> Messages { get; } = [];
    public string Root = "";
    public bool LooseFirst;
    public static string Key(string path) => new string(path.Replace('/', '\\').TrimStart('\\').Select(c => c >= 'A' && c <= 'Z' ? (char)(c + 32) : c).ToArray());
    public static string RawKey(string path) => Key(Encoding.Latin1.GetString(Encoding.GetEncoding(949, EncoderFallback.ExceptionFallback, DecoderFallback.ExceptionFallback).GetBytes(path)));
    public static string Display(string path) => Encoding.GetEncoding(949).GetString(Encoding.Latin1.GetBytes(path));
    static byte[] Inflate(byte[] data, int expected, int limit) {
        if (expected < 0 || expected > limit) throw new InvalidDataException("Decompressed size exceeds limit.");
        using var src = new MemoryStream(data);
        using var z = new ZLibStream(src, CompressionMode.Decompress);
        var output = new byte[expected];
        z.ReadExactly(output);
        if (z.ReadByte() != -1) throw new InvalidDataException("Decompressed length mismatch.");
        return output;
    }
    public void Load(string root, bool loose, CancellationToken ct, Action<string> progress) {
        Root = Path.GetFullPath(root); LooseFirst = loose;
        var ini = Path.Combine(Root, "DATA.ini");
        if (!File.Exists(ini)) throw new FileNotFoundException("Select client folder containing DATA.ini", ini);
        bool inData = false;
        var order = new SortedDictionary<int, string>();
        foreach (var line in File.ReadLines(ini)) {
            var t = line.Trim();
            if (t.StartsWith('[')) { inData = t.Equals("[Data]", StringComparison.OrdinalIgnoreCase); continue; }
            if (!inData) continue;
            var m = Regex.Match(t, @"^(\d+)\s*=\s*(.+?)\s*$");
            if (m.Success) order[int.Parse(m.Groups[1].Value)] = m.Groups[2].Value.Trim();
        }
        if (order.Count == 0) throw new InvalidDataException("No GRF entries in [Data].");
        foreach (var pair in order) {
            ct.ThrowIfCancellationRequested();
            string file = Path.GetFullPath(Path.Combine(Root, pair.Value));
            if (!file.StartsWith(Root + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("GRF path must remain inside client folder.");
            progress("Index: " + pair.Value);
            LoadGrf(file, ct);
            Messages.Add($"{pair.Key}: {file}");
        }
    }
    void LoadGrf(string file, CancellationToken ct) {
        using var fs = new FileStream(file, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
        using var r = new BinaryReader(fs);
        var h = r.ReadBytes(46);
        if (h.Length != 46 || Encoding.ASCII.GetString(h, 0, 15) != "Master of Magic")
            throw new InvalidDataException("Invalid GRF: " + file);
        if (BitConverter.ToUInt32(h, 42) != 0x200) throw new NotSupportedException("Only GRF 2.0 supported: " + file);
        fs.Position = 46L + BitConverter.ToUInt32(h, 30);
        int compressed = checked((int)r.ReadUInt32()), size = checked((int)r.ReadUInt32());
        if (compressed < 0 || compressed > 256 * 1024 * 1024 || compressed > fs.Length - fs.Position)
            throw new InvalidDataException("Invalid GRF table length.");
        var table = Inflate(r.ReadBytes(compressed), size, 256 * 1024 * 1024);
        int p = 0, duplicates = 0;
        while (p < table.Length) {
            ct.ThrowIfCancellationRequested();
            int end = Array.IndexOf(table, (byte)0, p);
            if (end < p || end - p > 4096 || table.Length - end - 1 < 17) throw new InvalidDataException("Malformed GRF table.");
            var name = Key(Encoding.Latin1.GetString(table, p, end - p));
            p = end + 1;
            int c = checked((int)BitConverter.ToUInt32(table, p));
            int original = checked((int)BitConverter.ToUInt32(table, p + 8));
            byte flags = table[p + 12];
            long offset = 46L + BitConverter.ToUInt32(table, p + 13);
            p += 17;
            if ((flags & 1) == 0) continue;
            if (offset > fs.Length || c < 0 || c > fs.Length - offset) throw new InvalidDataException("Invalid GRF entry bounds.");
            if (!Entries.TryAdd(name, new Asset(name, file, offset, c, original, flags))) duplicates++;
        }
        Messages.Add($"{Path.GetFileName(file)}: {duplicates:N0} lower-priority entries shadowed");
    }
    public (byte[] Bytes, string Source) Read(string rawPath, CancellationToken ct) {
        ct.ThrowIfCancellationRequested();
        string key = Key(rawPath);
        if (LooseFirst) {
            string relative = Display(key);
            var full = Path.GetFullPath(Path.Combine(Root, relative));
            if (full.StartsWith(Root + Path.DirectorySeparatorChar, StringComparison.OrdinalIgnoreCase) && File.Exists(full)) {
                if (new FileInfo(full).Length > 64 * 1024 * 1024) throw new InvalidDataException("Loose asset too large.");
                return (File.ReadAllBytes(full), full);
            }
        }
        if (!Entries.TryGetValue(key, out var e)) throw new FileNotFoundException("Resource missing: " + Display(key));
        if ((e.Flags & 6) != 0) throw new NotSupportedException("Encrypted GRF entry: " + e.Archive + " :: " + Display(key));
        if (e.Compressed > 64 * 1024 * 1024 || e.Size > 64 * 1024 * 1024) throw new InvalidDataException("Asset exceeds 64 MiB preview limit.");
        using var fs = new FileStream(e.Archive, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
        fs.Position = e.Offset;
        byte[] bytes = new byte[e.Compressed]; fs.ReadExactly(bytes);
        ct.ThrowIfCancellationRequested();
        return (Inflate(bytes, e.Size, 64 * 1024 * 1024), e.Archive + " :: " + Display(key));
    }
    public (byte[] Bytes, string Source) ItemImage(Item item, bool collection, CancellationToken ct) {
        if (string.IsNullOrEmpty(item.Resource)) throw new FileNotFoundException("No resource configured.");
        string folder = collection ? @"data\texture\유저인터페이스\collection\" : @"data\texture\유저인터페이스\item\";
        string resource = item.UnicodeResource ? RawKey(item.Resource) : item.Resource;
        return Read(RawKey(folder) + resource + ".bmp", ct);
    }
}

// Tokenizes literal Lua data; never executes client scripts.
public sealed class LuaData {
    readonly string text; int pos;
    public string Token = ""; public bool Quoted;
    public LuaData(string source) { text = source; Next(); }
    public void Next() {
        Quoted = false;
        while (pos < text.Length) {
            if (char.IsWhiteSpace(text[pos])) { pos++; continue; }
            if (pos + 1 < text.Length && text[pos..(pos+2)] == "--") {
                pos += 2;
                if (TryLong(out _)) continue;
                while (pos < text.Length && text[pos] != '\n') pos++;
                continue;
            }
            break;
        }
        if (pos >= text.Length) { Token = ""; return; }
        if (TryLong(out var longText)) { Token = longText; Quoted = true; return; }
        char c = text[pos++];
        if (c == '"' || c == '\'') {
            Quoted = true;
            var b = new StringBuilder(); bool closed = false;
            while (pos < text.Length) {
                char n = text[pos++];
                if (n == c) { closed = true; break; }
                if (n != '\\') { b.Append(n); continue; }
                if (pos >= text.Length) throw new InvalidDataException("Unterminated Lua escape.");
                n = text[pos++];
                if (n >= '0' && n <= '9') {
                    int v = n - '0', count = 1;
                    while (count < 3 && pos < text.Length && char.IsAsciiDigit(text[pos])) { v = v * 10 + text[pos++] - '0'; count++; }
                    if (v > 255) throw new InvalidDataException("Invalid Lua decimal escape.");
                    b.Append((char)v);
                } else b.Append(n switch { 'n' => '\n', 'r' => '\r', 't' => '\t', _ => n });
            }
            if (!closed) throw new InvalidDataException("Unterminated Lua string.");
            Token = b.ToString(); return;
        }
        if (char.IsLetterOrDigit(c) || c == '_') {
            int start = pos - 1;
            while (pos < text.Length && (char.IsLetterOrDigit(text[pos]) || text[pos] == '_')) pos++;
            Token = text[start..pos]; return;
        }
        Token = c.ToString();
    }
    bool TryLong(out string value) {
        value = "";
        if (pos >= text.Length || text[pos] != '[') return false;
        int p = pos + 1; while (p < text.Length && text[p] == '=') p++;
        if (p >= text.Length || text[p] != '[') return false;
        string close = "]" + new string('=', p-pos-1) + "]";
        int end = text.IndexOf(close, p+1, StringComparison.Ordinal);
        if (end < 0) throw new InvalidDataException("Unterminated Lua long string.");
        value = text[(p+1)..end]; pos = end + close.Length; return true;
    }
    public bool Eat(string value) { if (Quoted || Token != value) return false; Next(); return true; }
    public void Require(string value) { if (!Eat(value)) throw new InvalidDataException("Expected Lua token: " + value); }
    public object Value() {
        if (Quoted) { var s = Token; Next(); return s; }
        if (!Eat("{")) { var s = Token; if (s.Length == 0) throw new InvalidDataException("Unexpected end of Lua."); Next(); return s; }
        var map = new Dictionary<string, object>(); int index = 1;
        while (Token.Length > 0 && (Quoted || Token != "}")) {
            string key; object val;
            if (Eat("[")) { key = Token; Next(); Require("]"); Require("="); val = Value(); }
            else {
                string first = Token; bool wasString = Quoted; Next();
                if (!wasString && Eat("=")) { key = first; val = Value(); }
                else { key = (index++).ToString(); val = first; }
            }
            map[key] = val;
            if (!Eat(",")) Eat(";");
        }
        Require("}"); return map;
    }
    public static List<Item> Parse(byte[] bytes, string source, int codepage, CancellationToken ct) {
        if (bytes.Length > 0 && bytes[0] == 27) return LubData.Parse(bytes, source, codepage, ct);
        bool utf8 = codepage == 65001;
        string raw = utf8 ? Encoding.UTF8.GetString(bytes) : Encoding.Latin1.GetString(bytes);
        var l = new LuaData(raw); var result = new Dictionary<int,Item>();
        string Decode(string s) => utf8 ? s : Encoding.GetEncoding(codepage).GetString(Encoding.Latin1.GetBytes(s));
        while (l.Token.Length > 0) {
            ct.ThrowIfCancellationRequested();
            if (!l.Eat("[")) { l.Next(); continue; }
            if (!int.TryParse(l.Token, out int id)) { l.Next(); continue; }
            l.Next();
            if (!l.Eat("]") || !l.Eat("=") || l.Token != "{") continue;
            if (l.Value() is not Dictionary<string, object> values) continue;
            string Get(string key) => values.TryGetValue(key, out var v) ? v as string ?? "" : "";
            if (!values.ContainsKey("identifiedDisplayName")) continue;
            string description = values.TryGetValue("identifiedDescriptionName", out var d) && d is Dictionary<string,object> lines
                ? string.Join(Environment.NewLine, lines.Values.OfType<string>().Select(Decode)) : "";
            result[id] = new Item(id, Decode(Get("identifiedDisplayName")), Get("identifiedResourceName"), description, source, "", utf8);
        }
        if (result.Count == 0) throw new InvalidDataException("No literal itemInfo entries found. This parser does not execute Lua expressions.");
        return result.Values.OrderBy(x=>x.Id).ToList();
    }
}
public static class ItemDb {
    public static List<Item> Load(string file, CancellationToken ct) {
        using var reader = new StreamReader(file, new UTF8Encoding(false, true), true);
        var yaml = new YamlStream(); yaml.Load(reader);
        if (yaml.Documents.Count == 0 || yaml.Documents[0].RootNode is not YamlMappingNode root ||
            !root.Children.TryGetValue(new YamlScalarNode("Body"), out var body) || body is not YamlSequenceNode seq)
            throw new InvalidDataException("Select an item database with a Body list (not an import-only file).");
        var items = new Dictionary<int,Item>();
        foreach (var entry in seq.OfType<YamlMappingNode>()) {
            ct.ThrowIfCancellationRequested();
            string Field(string k) => entry.Children.TryGetValue(new YamlScalarNode(k), out var value) ? value.ToString() : "";
            if (!int.TryParse(Field("Id"), out var id)) continue;
            var name = Field("Name"); if (name.Length == 0) name = Field("AegisName");
            var raw = string.Join(Environment.NewLine, entry.Children.Select(kv => kv.Key + ": " + kv.Value));
            items[id] = new Item(id, name, "", raw, file, raw);
        }
        return items.Values.OrderBy(x=>x.Id).ToList();
    }
}
